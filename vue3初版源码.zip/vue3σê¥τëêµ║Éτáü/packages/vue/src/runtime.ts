// This entry exports the runtime only, and is built as
// `dist/vue.esm-bundler.js` which is used by default for bundlers.

export * from '@vue/runtime-dom'

import './devCheck'
