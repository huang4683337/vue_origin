export function renderToString() {
  // TODO
}
