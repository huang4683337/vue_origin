## Template Explorer

Live explorer for template compilation output.

To run:

- `yarn dev template-explorer`
- Open `index.html`.
